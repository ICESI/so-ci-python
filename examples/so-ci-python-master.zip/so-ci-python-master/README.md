# Travis Example

[![Build Status](https://travis-ci.org/ICESI/so-ci-travis.svg?branch=master)](https://travis-ci.org/ICESI/so-ci-travis)

This is a repository to show how travis works
